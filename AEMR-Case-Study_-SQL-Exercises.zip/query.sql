SELECT STATUS, REASON, COUNT(Status) AS TOtal_Number_Outage_Events
FROM AEMR
WHERE YEAR(Start_Time)=2016 AND Status='Approved'
GROUP BY Reason
ORDER BY Reason ASC
